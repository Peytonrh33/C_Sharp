using Microsoft.AspNetCore.Mvc;
namespace Practice.Controllers;

public class HelloController : Controller
{
    [HttpGet]
    [Route("")]
    public ViewResult Index()
    {
        return View("Index");
    }
}
