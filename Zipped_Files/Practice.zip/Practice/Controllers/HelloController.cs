using Microsoft.AspNetCore.Mvc;
namespace Practice.Controllers;

public class HelloController : Controller
{
    [HttpGet]
    [Route("")]
    public string Index()
    {
        return "This is my index!";
    }
    // Faster way of doing a route
    [HttpGet("projects")]
    public string Greet()
    {
        return "These are my projects";
    }
    [HttpGet("contact/{id}")]
    public string Contact(int id)
    {
        return $"This is my id: {id}";
    }
}